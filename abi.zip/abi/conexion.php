<?php
$server="localhost";
$user="abimael";
$pass="cbtis03";
$db="proyecto";
$conexion = new mysqli($server,$user,$pass,$db);

if($conexion->connect_error){
    die("la conexion a fallado" . $conexion->connect_error );
}else{echo "conectado";}



?>